public class Glove {
    private String strVocabulary;
    private Vector vecVector;

    public Glove(String _vocabulary, Vector _vector) {
        //TODO Task 2.1
    }

    public String getVocabulary() {
        //TODO Task 2.2
        return null;
    }

    public Vector getVector() {
        //TODO Task 2.3
        return null;
    }

    public void setVocabulary(String _vocabulary) {
        //TODO Task 2.4
    }

    public void setVector(Vector _vector) {
        //TODO Task 2.5
    }
}
